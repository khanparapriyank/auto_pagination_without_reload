module.exports.application = {
    name: "Product Book",
    author: "Khanpara Priyank",
    copyright: "&copy; NA"
}