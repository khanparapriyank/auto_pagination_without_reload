module.exports.myconf = {
    page_number : 1,
    newsList: [],
    isEndPage: false,
};