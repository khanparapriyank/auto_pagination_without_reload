/**
 * HomeController
 *
 * @description :: Server-side logic for managing homes
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */
 const axios = require('axios');

module.exports = {
    homeDefault: function (req, res) {
        console.log("Inside homepage Enter  .... ");
        const urlData = 'https://englishapi.xynie.com/app-api/v1/photo-gallery-feed-page/page/'+ req.params.page_number.toString();
        axios.get(urlData).then(response => {
            console.log("Inside homepage Found ........"+ req.params.page_number.toString());
            return res.json(response.data.nodes);
        }).catch((err) => {
            console.log("Inside homepage ERROR .... ");
            return res.status(500).send(err);
        });
    },
};
